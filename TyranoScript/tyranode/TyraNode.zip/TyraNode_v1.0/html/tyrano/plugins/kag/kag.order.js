
tyrano.plugin.kag.order ={

    tyrano:null,
    
    init:function(){
     
        //alert("kag.order 初期化");
        this.tyrano.test();
        
        //同じディレクトリにある、KAG関連のデータを読み込み
        
    },
    
    test:function(){
        
    }
};


