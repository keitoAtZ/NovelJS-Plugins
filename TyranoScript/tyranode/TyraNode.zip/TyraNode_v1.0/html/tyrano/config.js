var config = {
  
  init:{
      
      plugins:["kag"]
      
  },
    
  base:{
      
      width:"400",
      height:"320"
      
  },
  
  novel:{
        
  },
    
    
};

